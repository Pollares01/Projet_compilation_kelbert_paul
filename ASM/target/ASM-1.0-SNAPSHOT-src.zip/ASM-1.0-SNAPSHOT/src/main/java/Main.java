package main.java;

import fr.ul.miage.arbre.Noeud;
import fr.ul.miage.arbre.Prog;

import java.util.Scanner;

public class Main {


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        boolean stop = false;
        while(!stop){
            System.out.println("\n");
            System.out.print(
                "====================================\n" +
                        "          PROJET ASSEMBLEUR         \n" +
                        "====================================\n" +
                        "\t 1) Exemple 1\n" +
                        "\t 2) Exemple 2\n" +
                        "\t 3) Exemple 3\n" +
                        "\t 4) Exemple 4\n" +
                        "\t 5) Exemple 5\n" +
                        "\t 6) Exemple 6\n" +
                        "\t 7) Exemple 7\n" +
                        "\t 8) Exemple 8\n" +
                        "\t 9) Quitter\n" +
                        "\n Veuillez sélectionner un choix : "
            );
            String choix = scanner.nextLine();
            System.out.println("\n");
            switch (choix){
                case "1":
                    System.out.println("-- EXEMPLE 1 --");
                    Noeud prog = new Prog();
                    break;
                case "2":
                    System.out.println("-- EXEMPLE 2 --");
                    break;
                case "3":
                    System.out.println("-- EXEMPLE 3 --");

                    break;
                case "4":
                    System.out.println("-- EXEMPLE 4 --");

                    break;
                case "5":
                    System.out.println("-- EXEMPLE 5 --");

                    break;
                case "6":
                    System.out.println("-- EXEMPLE 6 --");

                    break;
                case "7":
                    System.out.println("-- EXEMPLE 7 --");

                    break;
                case "8":
                    System.out.println("-- EXEMPLE 8 --");

                    break;
                case "9":
                    stop = true;
                    break;
                default:
                    System.out.println("Veuillez sélectionner un choix de la liste.");
            }
        }
    }

}
